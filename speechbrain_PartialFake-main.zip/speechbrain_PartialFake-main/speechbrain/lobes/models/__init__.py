""" Package defining neural netword models (CRDNN, Xvectors ...)
"""
