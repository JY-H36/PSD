"""Package containing transducer neural networks
"""
