"""Package containing complex neural networks
"""
